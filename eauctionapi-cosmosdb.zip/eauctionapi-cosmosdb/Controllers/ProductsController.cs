﻿using eauctionapi_cosmosdb.Models;
using eauctionapi_cosmosdb.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eauctionapi_cosmosdb.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductsCosmosDbService _cosmosDbService;

        public ProductsController(IProductsCosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService ?? throw new ArgumentNullException(nameof(cosmosDbService));
        }

        // GET api/items
        [HttpGet]
        [Route("/e-auction/api/v1/seller/show-products")]
        public async Task<IActionResult> List()
        {
            return Ok(await _cosmosDbService.GetMultipleAsync("SELECT * FROM products"));
        }

        // GET api/items/5
        //[HttpGet("{id}")]
        [HttpGet]
        [Route("/e-auction/api/v1/seller/show-product/{id}")]
        public async Task<IActionResult> Get(string id)
        {
            return Ok(await _cosmosDbService.GetAsync(id));
        }

        // POST api/items
        [HttpPost]
        [Route("/e-auction/api/v1/seller/add-product")]
        public async Task<IActionResult> Create([FromBody] Product item)
        {
            item.Id = Guid.NewGuid().ToString();
            await _cosmosDbService.AddAsync(item);
            return CreatedAtAction(nameof(Get), new { id  = item.Id }, item);
        }

        // PUT api/items/5
        //[HttpPut("{id}")]
        [HttpPut]
        [Route("/e-auction/api/v1/seller/update-product/{id}")]
        public async Task<IActionResult> Edit([FromBody] Product item)
        {
            await _cosmosDbService.UpdateAsync(item.Id , item);
            return NoContent();
        }

        // DELETE api/items/5
        //[HttpDelete("{id}")]
        [HttpDelete]
        [Route("/e-auction/api/v1/seller/delete-product/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _cosmosDbService.DeleteAsync(id);
            return NoContent();
        }
    }
}

