﻿using eauctionapi_cosmosdb.Models;
using eauctionapi_cosmosdb.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eauctionapi_cosmosdb.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class BidsController : ControllerBase
    {
        private readonly IBidsCosmosDbService _cosmosDbService;

        public BidsController(IBidsCosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService ?? throw new ArgumentNullException(nameof(cosmosDbService));
        }

        // GET api/items
        [HttpGet]
        [Route("/e-auction/api/v1/buyer/show-bids")]
        public async Task<IActionResult> List()
        {
            return Ok(await _cosmosDbService.GetMultipleAsync("SELECT * FROM bids"));
        }

        // GET api/items/5
        //[HttpGet("{id}")]
        [HttpGet]
        [Route("/e-auction/api/v1/buyer/show-bid/{id}")]
        public async Task<IActionResult> Get(string id)
        {
            return Ok(await _cosmosDbService.GetAsync(id));
        }

        // POST api/items
        [HttpPost]
        [Route("/e-auction/api/v1/buyer/add-bid")]
        public async Task<IActionResult> Create([FromBody] Bid item)
        {
            item.Id = Guid.NewGuid().ToString();
            await _cosmosDbService.AddAsync(item);
            return CreatedAtAction(nameof(Get), new { id  = item.Id }, item);
        }

        // PUT api/items/5
        //[HttpPut("{id}")]
        [HttpPut]
        [Route("/e-auction/api/v1/buyer/update-bid/{id}")]
        public async Task<IActionResult> Edit([FromBody] Bid item)
        {
            await _cosmosDbService.UpdateAsync(item.Id , item);
            return NoContent();
        }

        // DELETE api/items/5
        //[HttpDelete("{id}")]
        [HttpDelete]
        [Route("/e-auction/api/v1/buyer/delete-bid/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _cosmosDbService.DeleteAsync(id);
            return NoContent();
        }
    }
}

