﻿using eauctionapi_cosmosdb.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eauctionapi_cosmosdb.Services
{
    public interface IBidsCosmosDbService
    {
        Task<IEnumerable<Bid>> GetMultipleAsync(string query);
        Task<Product> GetAsync(string id);
        Task AddAsync(Bid item);
        Task UpdateAsync(string id, Bid item);
        Task DeleteAsync(string id);
    }
}
