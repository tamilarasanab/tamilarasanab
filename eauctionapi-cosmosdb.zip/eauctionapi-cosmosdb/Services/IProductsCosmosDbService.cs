﻿using eauctionapi_cosmosdb.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eauctionapi_cosmosdb.Services
{
    public interface IProductsCosmosDbService
    {
        Task<IEnumerable<Product>> GetMultipleAsync(string query);
        Task<Product> GetAsync(string id);
        Task AddAsync(Product item);
        Task UpdateAsync(string id, Product item);
        Task DeleteAsync(string id);
    }
}
