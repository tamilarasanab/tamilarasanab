﻿using System.Text.Json.Serialization;
using System;

namespace eauctionapi_cosmosdb.Models
{
    public class Product
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("productId")]
        public string ProductId { get; set; }

        [JsonPropertyName("productName")]
        public string ProductName { get; set; }

        [JsonPropertyName("shortdescription")]
        public string ShortDescription { get; set; }

        [JsonPropertyName("detaildescription")]
        public string DetailDescription { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("startprice")]
        public float StartPrice{ get; set; }

        [JsonPropertyName("bidenddate")]
        public DateTime BidEndDate { get; set; }

        public SellerDetail SellerDetail { get; set; }
    }

    public class SellerDetail
    {
        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("address")]
        public string Address { get; set; }

        [JsonPropertyName("city")]
        public string City { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }

        [JsonPropertyName("pin")]
        public string Pin { get; set; }

        [JsonPropertyName("phone")]
        public string Phone { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }
        
    }

}
