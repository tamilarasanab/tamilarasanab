
export class Product {  
  id?: any
  productId?:string
  productName?:string
  shortdescription?:string
  detaildescription?:string
  category?:string
  startprice?:number
  bidenddate?:Date
}