
export class Bid {
  id?: any
  productId?:string
  firstName?:string
  lastName?:string
  address?:string
  city?:string
  state?:string
  pin?:string
  phone?:string
  email?:string
  bidAmount?:number
  }

  