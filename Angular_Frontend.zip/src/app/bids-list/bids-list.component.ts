import { Component, OnInit } from '@angular/core';
import { Bid } from 'src/app/models/bid.model';
import { Product } from 'src/app/models/product.model';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-bids-list',
  templateUrl: './bids-list.component.html',
  styleUrls: ['./bids-list.component.css']
})
export class BidsListComponent implements OnInit {

  page = 1;
  pageSize = 4;
  collectionSize = 0;
  bids!: Bid[];
  products!: Product[];
  product!: Product;
 
  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.fetchProductsList();

    this.refreshBids();
  }

  refreshBids() {
    this.sharedService.getBidsList()
    .subscribe(
      data => {
        this.bids = data;
        this.bids=this.bids.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
        this.collectionSize = this.bids.length;
        console.log(data);
      },
      error => {
        console.log(error);
      });

      //this.bids=this.bids.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
 
  fetchProductsList() {
    this.sharedService.getProductList()
    .subscribe(
      data => {
        this.products = data;
        console.log(data);
      },
      error => {
        console.log(error);
      });     
  }

  fetchproduct(id: any){
    console.log(id);
    this.sharedService.getProduct(id)
    .subscribe(
      data => {
        this.product = data;
        console.log(data);
      },
      error => {
        console.log(error);
      });     

  }

}
