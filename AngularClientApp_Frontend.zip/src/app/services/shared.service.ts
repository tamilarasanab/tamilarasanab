import { Injectable } from '@angular/core';    
import {HttpClient} from '@angular/common/http';    
import {Observable} from 'rxjs';    
import {Bid} from '../models/bid.model';
import {Product} from '../models/product.model';
@Injectable({  
    providedIn: 'root'  
})  

export class SharedService {  
    readonly APIUrl = "https://eauctionapi-cosmosdb20210922142556.azurewebsites.net/e-auction/api/v1";  
    constructor(private http: HttpClient) {}  
    getProductList(): Observable < Product[] > {  
        return this.http.get <Product[]> (this.APIUrl + '/seller/show-products');  
    }  
    getProduct(id: any): Observable<Product> {
        console.log(id);
        return this.http.get<Product>(this.APIUrl + '/seller/show-product/' + id);
    }
    getBidsList(): Observable < Bid[] > {  
        return this.http.get < Bid[] > (this.APIUrl + '/buyer/show-bids');  
    }  
}   