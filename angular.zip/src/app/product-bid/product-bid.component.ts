import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-bid',
  templateUrl: './product-bid.component.html',
  styleUrls: ['./product-bid.component.css']
})
export class ProductBidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
