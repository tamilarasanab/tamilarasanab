import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ProductBidComponent} from './product-bid/product-bid.component';

const routes: Routes = [
  {path:'product-bid',component:ProductBidComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
