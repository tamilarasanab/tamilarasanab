using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace eauctionservicebusdemo
{
    public static class ReceiveMessage
    {
        [FunctionName("ReceiveMessage")]
        public static void Run([ServiceBusTrigger("azqueue")] string myQueueItem, [CosmosDB(
        databaseName: "eauction",
        collectionName: "products",
        ConnectionStringSetting = "CosmosDbConnectionString",
        SqlQuery = "Delete fro")], ILogger log)
        {
            log.LogInformation($"C# ServiceBus queue trigger function processed message: {myQueueItem}");
           
        }
    }
}
