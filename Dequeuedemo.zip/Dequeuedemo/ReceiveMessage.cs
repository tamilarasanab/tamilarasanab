using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace eauctionservicebusdemo
{
    public class dataModel
    {
        public string id { get; set; }
    }
    public static class ReceiveMessage
    {
        private static HttpClient httpClient = new HttpClient();

        [FunctionName("ReceiveMessage")]
        public static void Run([ServiceBusTrigger("azqueue")] string myQueueItem, ILogger log)
        {
            log.LogInformation($"C# ServiceBus queue trigger function processed message: {myQueueItem}");
            
            DeleteProductAsync(myQueueItem, httpClient);

        }

        static async void DeleteProductAsync(string jsonData,HttpClient httpClient)
        {
            dataModel data = JsonConvert.DeserializeObject<dataModel>(jsonData);
            await httpClient.DeleteAsync($"https://eauctionapi-cosmosdb20210922142556.azurewebsites.net/e-auction/api/v1/seller/delete-product/" + data.id);
        }
      
    }
}
